package parcialprog2;

import static config.AppConstants.PATH_CSV;
import static config.AppConstants.PATH_SERIAL;

import modelo.Personaje;
import modelo.Inventario;
import modelo.ClasePersonaje;

import java.io.IOException;

public class Test {

    public static void main(String[] args) {
        // Crear un inventario de personajes jugables
        Inventario<Personaje> inventarioPersonajes = new Inventario<>();
        inventarioPersonajes.agregar(new Personaje(1, "Aragorn", ClasePersonaje.GUERRERO, 20));
        inventarioPersonajes.agregar(new Personaje(2, "Gandalf", ClasePersonaje.MAGO, 50));
        inventarioPersonajes.agregar(new Personaje(3, "Legolas", ClasePersonaje.ARQUERO, 25));
        inventarioPersonajes.agregar(new Personaje(4, "Frodo", ClasePersonaje.GUERRERO, 10));
        inventarioPersonajes.agregar(new Personaje(5, "Saruman", ClasePersonaje.MAGO, 40));
        inventarioPersonajes.agregar(new Personaje(6, "Robin Hood", ClasePersonaje.ARQUERO, 30));
        separador();
        System.out.println("Personajes: ");
        inventarioPersonajes.paraCadaElemento(System.out::println);
        // Ordenar personajes de manera natural (por nombre)
        separador();
        System.out.println("Personajes ordenados por nombre: ");
        inventarioPersonajes.ordenar();
        inventarioPersonajes.paraCadaElemento(System.out::println);
        // Ordenar personajes por nivel utilizando un Comparator
        System.out.println("Personajes ordenados por nivel: ");
        separador();
        inventarioPersonajes.ordenar((p1, p2) -> Integer.compare(p1.getNivel(), p2.getNivel()));
        inventarioPersonajes.paraCadaElemento(System.out::println);
        // Filtrar personajes de clase MAGO
        separador();
        System.out.println("Personajes MAGOS: ");
        inventarioPersonajes.filtrar(personaje -> personaje.getClase() == ClasePersonaje.MAGO)
                .forEach(System.out::println);
        // Transformar personajes: aumentar nivel en +5
        separador();
        System.out.println("Personajes con +5 de nivel: ");
        inventarioPersonajes.transformar(personaje -> {
            personaje.setNivel(personaje.getNivel() + 5);
            return personaje;
        });
        inventarioPersonajes.paraCadaElemento(System.out::println);
        // Guardar el inventario en un archivo binario
        System.out.println("Inventario guardado en un archivo binario: ");
        separador();
        inventarioPersonajes.guardarEnArchivo(PATH_SERIAL);
        System.out.println("Inventario guardado en " + PATH_SERIAL);
        // Cargar el inventario desde el archivo binario
        separador();
         System.out.println("Inventario cargado desde un archivo binario: ");
        Inventario<Personaje> inventarioCargado = new Inventario<>();
        inventarioCargado.cargarDesdeArchivo(PATH_SERIAL);
        inventarioCargado.paraCadaElemento(System.out::println);
        // Guardar el inventario en un archivo CSV
        separador();
      
        inventarioCargado.limpiar();
        inventarioPersonajes.guardarEnCSV(PATH_CSV);
        System.out.println("Inventario guardado en " + PATH_CSV);
        // Cargar el inventario desde el archivo CSV
        separador();
         System.out.println("Inventario cargado desde un archivo binario: ");
        inventarioCargado.cargarDesdeCSV(PATH_CSV, Personaje::fromCSV);
        inventarioCargado.paraCadaElemento(System.out::println);
        
        // no implemente el catch en en test.java porque lo implemente en el metodo
    }

    
    public static void separador() {
        System.out.println("-------------------------------------------");
    }
}
