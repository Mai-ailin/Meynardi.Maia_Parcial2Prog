package modelo;

import java.io.Serializable;

public class Personaje implements Comparable<Personaje>, CSVSerializable, Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private ClasePersonaje clase;
    private int nivel;

    public Personaje(int id, String nombre, ClasePersonaje clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }
    
    
    public ClasePersonaje getClase() {
        return clase;
    }

    public void setClase(ClasePersonaje clase) {
        this.clase = clase;
    }
    
    @Override
    public String toString() {
        return "Personaje{"+ "ID"+ id + ", Nombre=" + nombre + ", Clase=" + clase + ", Nivel=" + nivel + '}';
    }
    

    @Override
   public int compareTo(Personaje p) {
        return this.nombre.compareTo(p.nombre);
   }
   

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + clase + "," + nivel;
    }
    
    public static Personaje fromCSV(String csv) {
        String[] values = csv.split(",");
        int id = Integer.parseInt(values[0]);
        String nombre = values[1];
        ClasePersonaje clase = ClasePersonaje.valueOf(values[2]); 
        int nivel = Integer.parseInt(values[3]);
        return new Personaje(id, nombre, clase, nivel);
    }
    
    public static void validarId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("El ID debe ser un número positivo.");
        }
    }

    
    public static void validarNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío o ser nulo.");
        }
    }

    
    public static void validarClase(ClasePersonaje clase) {
        if (clase == null) {
            throw new IllegalArgumentException("La clase del personaje no puede ser nula.");
        }
    }

    

    public void validarPersonaje() {
        validarId(this.id);
        validarNombre(this.nombre);
        validarClase(this.clase);
        
    }
}
