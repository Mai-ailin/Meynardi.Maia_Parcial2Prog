package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T> implements Serializable{
    private static final long serialVersionUID = 1L;
    
    private List<T> personajes = new ArrayList<>();
    
    
    public void agregar(T personaje) {
        if (personaje == null) {
            throw new IllegalArgumentException("El personaje no puede ser nulo.");
        }
        if (personaje instanceof Personaje) {
            ((Personaje) personaje).validarPersonaje();
    }
        personajes.add(personaje);
    }

    public T obtener(int indice) {
        validarIndice(indice);
        return personajes.get(indice);
    }

    public void eliminar(int indice) {
        validarIndice(indice);
        personajes.remove(indice);
    }

    public int tamanio() {
        return personajes.size();
    }
        
    private void validarIndice(int indice) {
        if (indice < 0 || indice >= personajes.size()) {
            throw new IndexOutOfBoundsException("Índice inválido.");
        }
    }
    
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T personaje : personajes) {
            accion.accept(personaje);
        }
    }
    
    public void listar() {
        for (T personaje : personajes) {
            System.out.println(personaje);
        }
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        for (T personaje : personajes) {
            if (criterio.test(personaje)) {
                aux.add(personaje);
            }
        }
        return aux;
    }
    
    public void ordenar() {
        ordenar((Comparator<? super T>) Comparator.naturalOrder());
    }

    public void ordenar(Comparator<? super T> comparador) {
        personajes.sort(comparador);
    }
    
    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        List <T> toReturn = new ArrayList<>();
        for (T personaje : personajes){
            toReturn.add(transformacion.apply(personaje));
        }
        return toReturn;
    }
    
    public Iterator<T> iterator() {
        if (!personajes.isEmpty() && personajes.get(0) instanceof Comparable) {
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return (new ArrayList<T>(personajes)).iterator();
    }

    public Iterator<T> iterator(Comparator<? super T> comparador) {
        ArrayList<T> aux = new ArrayList<>(personajes);
        aux.sort(comparador);
        return aux.iterator();
    }
    
    public void guardarEnArchivo(String path) {
    try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
        salida.writeObject(personajes);
    } catch (IOException ex) {
        System.out.println(ex.getMessage());
    }
}

    public void cargarDesdeArchivo(String path) {
        
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            personajes = (List<T>) entrada.readObject();

        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        
    }
    
    public void guardarEnCSV(String path) {
    File archivo = new File(path);

    try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
        bw.write("Id,Nombre,Clase,Nivel\n");
        for (T personaje : personajes) {
            if(personaje instanceof CSVSerializable) {
                CSVSerializable csv = (CSVSerializable) personaje;
                bw.write(csv.toCSV() + "\n");
            }
        }
    } catch (IOException ex) {
        System.out.println(ex.getMessage());
    }
}    
    public void cargarDesdeCSV(String path, Function<String, T> fromCSV) {
    File archivo = new File(path);
    try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
        String linea;
        br.readLine(); 
        while ((linea = br.readLine()) != null) {
            if (linea.endsWith("\n")) {
                linea = linea.substring(0, linea.length() - 1);
            }
            T elemento = fromCSV.apply(linea); 
            personajes.add(elemento);
        }
    } catch (IOException ex) {
        System.out.println(ex.getMessage());
    }
}
    public void limpiar() {
        personajes.clear(); }
    
}

