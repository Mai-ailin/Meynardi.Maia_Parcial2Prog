package modelo;

public enum ClasePersonaje {
    GUERRERO,
    MAGO,
    ARQUERO
}
